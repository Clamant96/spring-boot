package com.helloworld.mentalidadesehabilidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentalidadesehabilidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
