package com.helloworld.objetivosdeaprendizagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjetivosdeaprendizagemApplicationTests {

	@Test
	void contextLoads() {
	}

}
